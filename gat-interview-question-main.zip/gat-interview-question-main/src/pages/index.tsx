import { RoomingList } from "components";
import { NextPage } from "next";
import { useState } from "react";

const IndexPage: NextPage = () => {
    const [nbTravelers, setNbTravelers] = useState(2);
    return (
        <div>
            <div style={{ marginBottom: 32 }}>
                <input
                    type="number"
                    value={nbTravelers}
                    onChange={(e) => setNbTravelers(parseInt(e.currentTarget.value))}
                />
            </div>
            <RoomingList nbTravelers={nbTravelers}/>
        </div>
    );
}

export default IndexPage;
