import "@testing-library/jest-dom";
import { render, waitFor } from "@testing-library/react";
import React from "React";
import { RoomingList } from "./RoomingList";

it("Renders the component.", async () => {
    const component = render(<RoomingList nbTravelers={0} />)
    waitFor(() => expect(component.getByTestId("rooming-list")).toBeInTheDocument());
});