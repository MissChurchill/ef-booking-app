import { Room } from "models";
import { useEffect, useState } from "react"

export const useRooms = () => {
    const [rooms, setRooms] = useState<Room[]>([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        fetch("/api/rooming").then((res) => res.json()).then((data) => {
            setRooms(data);
            setLoading(false);
        });
    }, []);
    return {
        loading,
        rooms,
    };
}
