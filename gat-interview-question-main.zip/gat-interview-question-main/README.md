# README

In this project you'll find a mock problem that mirrors a real-life user story completed by an EF Go Ahead Tours Engineer in the past.

Feel free to solve this problem in whatever language/platform/stack you'd prefer or use this repo as a base.

## The problem

*User story:*

As a user, I'd like to be able to book more than 5 travelers at checkout.

*Description*

Today in checkout users are able to book at most 5 people. As a result, the existing implementations have simple hard coded values to represent all possible room combinations.

*Acceptance Criteria*

- Dynamically generate all possible combinations of rooms a group of X travelers could have.
- Refactor the components to clean up any loose types, poorly structured components, etc
- Write a test to cover the combination generation, using the provided Jest configuration or your testing framework of choice 

*Additional information*

- This repo uses NextJS with TypeScript - https://nextjs.org/docs/getting-started
- The room data is mocked coming from a NextJS api endpoint located in pages/api
- To start the app run `npm i` and then `npm run dev`
- Styling doesn't matter for this problem, clean code does


## Follow up

In the next phase of the interview, you will be expected to walk a senior engineer through your code in a mock Code Review.
