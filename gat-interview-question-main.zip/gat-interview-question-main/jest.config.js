
/** @type {import('@jest/types').Config.InitialOptions} */
module.exports = {
    moduleDirectories: [
        "node_modules",
        "src"
    ],
    moduleNameMapper: {
        "^~(.*)$": "<rootDir>/src/$1"
    },
    setupFiles: [
        "jest-canvas-mock",
        "./test/next-dynamic-setup.js",
        "./test/fetch-setup.js"
    ],
    testEnvironment: "jest-environment-jsdom",
    testPathIgnorePatterns: [
        "<rootDir>/.next/",
        "<rootDir>/node_modules/"
    ],
    transform: {
        "^.+\\.(js|jsx|ts|tsx)$": ["babel-jest", {presets: ["next/babel"]}],
    },
}